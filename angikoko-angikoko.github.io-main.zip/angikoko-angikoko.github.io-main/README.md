hi i'm angikoko, an italian student that for his exam progect want to create a website using my two passions : coding and astronomy.
Basicaly i'll do a map with launch stations and other things about nasa, but i want to add other things to build a real community.
I'll do the project alone, but after the exam if someone want can help me with this project.
